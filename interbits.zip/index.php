<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html class="no-js" lang="en"> <!--<![endif]--><head>

        <!-- Basic Page Needs
  ================================================== -->
        <meta charset="utf-8">
        <title>Your Page Title Here :)</title>
        <meta name="description" content="">
        <meta name="author" content="">

        <!-- Mobile Specific Metas
  ================================================== -->
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

        <!-- CSS
  ================================================== -->
        <link rel="stylesheet" href="stylesheets/base.css">
        <link rel="stylesheet" href="stylesheets/skeleton.css">
        <link rel="stylesheet" href="stylesheets/layout.css">
        <link rel="stylesheet" href="stylesheets/style.css">
        
        <!--[if lt IE 9]>
                <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->

        <!-- Favicons
        ================================================== -->
        <link rel="shortcut icon" href="images/favicon.ico">
        <link rel="apple-touch-icon" href="images/apple-touch-icon.png">
        <link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
        <link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
        
        <script type="text/javascript" src="js/libs/jquery_171.js"></script>
        <script type="text/javascript" src="js/libs/slider/coin-slider.min.js"></script>
        <script type="text/javascript" src="js/libs/menu/magic-line.js"></script>
        
        <script type="text/javascript" src="js/libs/util/dictionary.js"></script>
        <script type="text/javascript" src="js/libs/util/menu.js"></script>
        <script type="text/javascript" src="js/libs/util/slider.js"></script>
        <script type="text/javascript" src="js/home.js"></script>
        
        <script type="text/javascript">
            $(document).ready(function() {
                home = new Home();
                home.init();
            });
        </script>
    </head>
    <body>
        <div id="bg">

            <!-- Primary Page Layout
            ================================================== -->

            <!-- Delete everything in this .container and get started on your own site! -->

            <!-- top -->

            <div class="sub">
                <div class="container">
                    <div class="container">
                        <div class="sub_top">
                            <span>Fone: 11 3549-3988</span>
                            <span>Atendimento on-line</span>
                            <span>Idiomas </span>
                        </div>
                    </div>
                    <div class="logo"><img src="images/logo_spweb.png"></div>
                    <div id="login">
                        <div id="aba_aluno" class="aluno_inativa">
                            <a href="javascript:void(0);" onclick="javascript:home.changeArea('aluno');">
                                Aluno
                            </a>
                        </div>
                        <div id="aba_assinante" class="assinante_ativa">
                            <a href="javascript:void(0);" onclick="javascript:home.changeArea('assinante');">
                                Assinante
                            </a>
                        </div>
                        <div id="area_assinante" class="area_assinante">
                            <input id="altura" class="text" type="text" value="Nome" name="Nome">
                            <input id="altura" class="text" type="text" value="Senha" name="Senha" >
                            <div class="bt"></div>
                            <div class="senha">
                                <a href="">
                                    Esqueci minha senha
                                </a>
                            </div>
                        </div>
                        <div id="area_aluno" class="area_aluno" style="display:none;">
                            <input id="altura" class="text" type="text" value="E-mail" name="email">
                            <input id="altura" class="text" type="text" value="Senha" name="senha" >
                            <input id="altura" class="text" type="text" value="Código da Lista" name="codigo">
                            <div class="bt"></div>
                            <div class="senha">
                                <a href="">
                                    Esqueci minha senha
                                </a>
                            </div>
                        </div>
                        <div class="area2">Não sou Cadastrado</div>
                    </div>
                </div>
            </div>
            <!-- fim top -->
            <!-- começo menu -->
            <div class="top">
                <div class="container nav-wrap">
                    <ul class="group" id="top-menu">
                        <li id="menu_home" class="current_page_item" onclick="javascript:menu.changeMenu(this.id);">
                            <a href="javascript:void(0);">Home</a>
                        </li>
                        <li id="menu_sobre" onclick="javascript:menu.changeMenu(this.id);">
                            <a href="javascript:void(0);">Sobre Nós</a>
                        </li>
                        <li id="menu_planos" onclick="javascript:menu.changeMenu(this.id);">
                            <a href="javascript:void(0);">Planos e Serviços</a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- fim menu -->
            <div class="container">
                <div id='banner' style="width:900px;height:400px;">
                    <a href="#" target="_blank">
                        <img src='images/banner.png' style="width:900px;height:400px;" />
                    </a>
                    <a href="#" target="_blank">
                        <img src='images/banner2.png' style="width:900px;height:400px;" />
                    </a>
                </div>
                <div class="five columns">
                    <div id="grafico">
                        <h1>98%</h1><h3>dos</h3>
                        <h2>nossos assinantes indicam</h2>
                    </div>
                </div>
                <div class="five columns">
                    <div class="perguntas">
                        <h1>100.667 </h1><span>Questões</span>
                        <h2>1.655 </h2><spam>ENEM</spam>
                    </div>
                </div>
                <div class="five columns">
                    <div class="experimente">
                        <h1>Experimente</h1><h2>Já</h2>
                        <span>Grátis</span>
                    </div>
                </div>
                <div class="five columns">
                    <div class="icon_home">
                        <h3>Motivos para Usar o SuperPro®</h3>
                    </div>
                    <div id="lista">
                        <p><span>1.</span> Lorem Ipsum</p>
                        <p><span>2.</span> Lorem Ipsum</p>
                        <p><span>3.</span> Lorem Ipsum</p>
                        <p><span>4.</span> Lorem Ipsum</p>
                        <p><span>5.</span> Lorem Ipsum</p>
                    </div>
                    <button class="buttonsaibamais">Saiba +</button>
                </div>
                <div class="five columns">
                    <div class="icon_home2">
                        <h3>Prepare sua Prova Rapidamente</h3>
                    </div>
                    <div id="lista2">
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                    </div>
                    <button class="buttonsaibamais">Veja o resultado</button>
                </div>
                <div class="five columns">
                    <div class="icon_home3">
                        <h3><span>Crie exercícios Online</span> Para seus Alunos</h3>
                    </div>
                    <div id="lista2">
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                        <p>Lorem ipsum dolor sit amet, elit, consectetuer adipiscing elit,</p>
                    </div>
                    <button class="buttonsaibamais">Saiba +</button>
                </div>
            </div>
            <!-- container -->

            <!-- espaçamento -->
            <div id="margem"></div>

            <!-- começo rodape -->
            <div class="azul_rodape_superior">      
                <div class="container">      
                    <div class="four columns">
                        <div id="menu3"><h1>Sobre Nós</h1>
                            <ul>
                                <li><a href="">A Interbits</a></li>
                                <li><a href="">Entre em contato</a></li>
                                <li><a href="">Politica de Privacidade</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="four columns">
                        <div id="menu3"><h2>Planos & Preços</h2>
                            <ul>
                                <li><a href="">Assine Já</a></li>
                                <li><a href="">Principais recursos</a></li>
                                <li><a href="">Formas de pagamento</a></li>
                            </ul>

                        </div>

                    </div>
                    <div class="four columns">
                        <div id="menu3"><h3>Ajuda</h3>
                            <ul>
                                <li><a href="">F.A.Q</a></li>
                                <li><a href="">Tutóriais</a></li>
                                <li><a href="">Fale com o Suporte</a></li>
                                <li><a href="">Chat On-line</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="four columns">
                        <button class="buttonSuperPro"><span>Conheça o</span>
                            <p>SuperPro<span>® </span> WEB</p></button>
                        <div class="end">    	
                            Suporte técnico: (11) 3549-3985<br/>
                            Comercial: (11) 3549-3982<br/>
                            Fone PABX: (11) 3549-3988
                        </div>
                        <div class="midias"></div>
                        <div class="midias2"></div>
                        <div class="midias3"></div>



                    </div>


                </div>

            </div><!-- final rodape -->
            <div class="azul_rodape">
                <div class="container" align="center">
                    Copyright Interbits © 2012  -  todos os direitos reservados      
                </div>
            </div>

            <!-- End Document
            ================================================== -->
        </div>
    </body>
</html>