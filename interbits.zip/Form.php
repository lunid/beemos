<?php

namespace app\lib\ecomm;

/**
 * Minha classe Form
 */
class Form{
    /**
     * Teste de Form
     */
    public function __construct() {
        
    }
}
?>
